#!/bin/bash
(/home/phi.richter/radiative_transfer/lbldis/lbldis /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_15_41_52_114463/.lbldis_0.parm 0 /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_15_41_52_114463/.lbldisout_0) >& /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_15_41_52_114463/.lbldislog_0.txt
