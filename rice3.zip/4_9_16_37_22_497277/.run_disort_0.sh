#!/bin/bash
(/home/phi.richter/radiative_transfer/lbldis/lbldis /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_16_37_22_497277/.lbldis_0.parm 0 /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_16_37_22_497277/.lbldisout_0) >& /home/phi.richter/TCWret/OUTFOLDER/PS.20170611_230800.nc/4_9_16_37_22_497277/.lbldislog_0.txt
